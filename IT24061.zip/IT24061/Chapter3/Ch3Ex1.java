import java.util.Scanner;
public class Ch3Ex1{
 public static void main(String[] args){
  Scanner input=new Scanner(System.in);
  System.out.print("Enter a,b,c: ");
  double a=input.nextDouble(),b=input.nextDouble(),c=input.nextDouble();
  double d=b*b-4*a*c;
  if(d>0){ double r1=(-b+Math.sqrt(d))/(2*a), r2=(-b-Math.sqrt(d))/(2*a); System.out.println("Two roots: "+r1+" and "+r2); }
  else if(d==0){ double r=-b/(2*a); System.out.println("One root: "+r); }
  else{ System.out.println("No real roots"); }
 }
}