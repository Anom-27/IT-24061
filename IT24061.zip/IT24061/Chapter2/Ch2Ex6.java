import java.util.Scanner;
public class Ch2Ex6 {
  public static void main(String[] args){
    Scanner input=new Scanner(System.in);
    System.out.print("Enter an integer 0-1000: ");
    int n=input.nextInt();
    int sum=(n%10)+(n/10%10)+(n/100);
    System.out.println("Sum of digits: " + sum);
  }
}