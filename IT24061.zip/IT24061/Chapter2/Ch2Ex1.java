import java.util.Scanner;
public class Ch2Ex1 {
  public static void main(String[] args){
    Scanner input = new Scanner(System.in);
    System.out.print("Enter Celsius: ");
    double c = input.nextDouble();
    double f = 9.0/5*c + 32;
    System.out.println(c + " Celsius is " + f + " Fahrenheit");
  }
}